
# Advanced Python `types` Module — Exercises Workbook

> **Goal:** Master Python runtime object types from the `types` module and CPython internals.
> Order of questions does **not** matter — **coverage does**.

---

## Types Covered

- MappingProxyType
- FunctionType
- LambdaType
- MethodType
- BuiltinFunctionType
- BuiltinMethodType
- ModuleType
- GeneratorType
- AsyncGeneratorType
- CoroutineType
- CodeType
- FrameType
- TracebackType
- MemberDescriptorType
- WrapperDescriptorType
- GetSetDescriptorType
- EllipsisType
- NotImplementedType

---

## Exercises

### Exercise 1 — `MappingProxyType`
Create a dictionary and expose a read-only view.

### Exercise 2 — `FunctionType`
Verify that a normal function is an instance of `FunctionType`.

### Exercise 3 — `LambdaType`
Show that lambdas are also functions internally.

### Exercise 4 — `MethodType`
Manually bind a function to an instance.

### Exercise 5 — `BuiltinFunctionType`
Inspect built-in functions like `len`.

### Exercise 6 — `BuiltinMethodType`
Check the type of `list.append`.

### Exercise 7 — `ModuleType`
Confirm imported modules are module objects.

### Exercise 8 — `GeneratorType`
Create and inspect a generator.

### Exercise 9 — `AsyncGeneratorType`
Create an async generator and inspect its type.

### Exercise 10 — `CoroutineType`
Inspect the object returned from an async function.

### Exercise 11 — `CodeType`
Extract and inspect a function’s compiled bytecode.

### Exercise 12 — `FrameType`
Capture the current execution frame.

### Exercise 13 — `TracebackType`
Trigger an exception and inspect its traceback.

### Exercise 14 — `MemberDescriptorType`
Inspect class attribute descriptors like `__dict__`.

### Exercise 15 — `WrapperDescriptorType`
Inspect low-level built-in descriptors.

### Exercise 16 — `GetSetDescriptorType`
Inspect properties implemented in C.

### Exercise 17 — `EllipsisType`
Inspect the `Ellipsis` singleton.

### Exercise 18 — `NotImplementedType`
Correctly return `NotImplemented` in comparisons.

---

## Solutions

### Solution 1 — `MappingProxyType`
```python
from types import MappingProxyType

d = {'a': 1}
mp = MappingProxyType(d)
print(mp['a'])
```

### Solution 2 — `FunctionType`
```python
from types import FunctionType

def f(): pass
print(isinstance(f, FunctionType))
```

### Solution 3 — `LambdaType`
```python
from types import FunctionType

lam = lambda x: x
print(isinstance(lam, FunctionType))
```

### Solution 4 — `MethodType`
```python
from types import MethodType

class A: pass

def hello(self):
    return 'hello'

a = A()
a.hello = MethodType(hello, a)
print(a.hello())
```

### Solution 5 — `BuiltinFunctionType`
```python
from types import BuiltinFunctionType

print(isinstance(len, BuiltinFunctionType))
```

### Solution 6 — `BuiltinMethodType`
```python
from types import BuiltinMethodType

lst = []
print(isinstance(lst.append, BuiltinMethodType))
```

### Solution 7 — `ModuleType`
```python
from types import ModuleType
import math

print(isinstance(math, ModuleType))
```

### Solution 8 — `GeneratorType`
```python
from types import GeneratorType

def gen():
    yield 1

g = gen()
print(isinstance(g, GeneratorType))
```

### Solution 9 — `AsyncGeneratorType`
```python
from types import AsyncGeneratorType

async def agen():
    yield 1

ag = agen()
print(isinstance(ag, AsyncGeneratorType))
```

### Solution 10 — `CoroutineType`
```python
from types import CoroutineType

async def coro():
    return 42

c = coro()
print(isinstance(c, CoroutineType))
```

### Solution 11 — `CodeType`
```python
from types import CodeType

def f(): pass

print(isinstance(f.__code__, CodeType))
```

### Solution 12 — `FrameType`
```python
from types import FrameType
import sys

frame = sys._getframe()
print(isinstance(frame, FrameType))
```

### Solution 13 — `TracebackType`
```python
from types import TracebackType
import sys

try:
    1 / 0
except Exception:
    tb = sys.exc_info()[2]
    print(isinstance(tb, TracebackType))
```

### Solution 14 — `MemberDescriptorType`
```python
from types import MemberDescriptorType

print(isinstance(int.__dict__['numerator'], MemberDescriptorType))
```

### Solution 15 — `WrapperDescriptorType`
```python
from types import WrapperDescriptorType

print(isinstance(int.__add__, WrapperDescriptorType))
```

### Solution 16 — `GetSetDescriptorType`
```python
from types import GetSetDescriptorType

print(isinstance(type.__dict__['__mro__'], GetSetDescriptorType))
```

### Solution 17 — `EllipsisType`
```python
from types import EllipsisType

print(isinstance(Ellipsis, EllipsisType))
```

### Solution 18 — `NotImplementedType`
```python
class A:
    def __eq__(self, other):
        if not isinstance(other, A):
            return NotImplemented
        return True

print(A() == 1)
```
