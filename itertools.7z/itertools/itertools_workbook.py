# Markdown content for Advanced Python itertools Exercises Workbook
# generated and saved to a .md file
# Created by ChatGPT
# Modified by Muhammed Shafin P
# For PDF: pandoc itertools_exercises_workbook.md -o itertools_exercises_workbook.pdf --pdf-engine=xelatex -V title="Advanced Python Itertools Workbook" -V author="Muhammed Shafin P" -V date="03-01-2026"
# Pdf generated on 03-01-2026
# Pdf genearted with xelatex engine by MikTeX
# Pdf genrated using pandoc

md_content = '''
# Advanced Python `itertools` Exercises Workbook

> **Instructions:** Solve the following exercises using Python. The solutions are provided in the **Solutions** section at the end.

## Exercises

### Section 1 — Infinite Iterators

**Exercise 1 — `count`**
- Create an iterator that counts from 10 by 3. Print the first 5 numbers using `next()`.

**Exercise 2 — `cycle`**
- Cycle through the list `["A", "B", "C"]` and print the first 10 elements.

**Exercise 3 — `repeat`**
- Repeat the string `"Hello"` 5 times.
- Repeat the number `42` infinitely and break after printing 7 numbers.

### Section 2 — Finite Iterators / Combinatorics

**Exercise 4 — `accumulate`**
- Compute the running sum of `[1, 2, 3, 4]`.
- Compute running products of `[1, 2, 3, 4]` using `operator.mul`.

**Exercise 5 — `chain` and `chain.from_iterable`**
- Chain the lists `[1,2]` and `[3,4]`.
- Flatten `[[1,2],[3,4],[5]]` using `chain.from_iterable`.

**Exercise 6 — `combinations` and `combinations_with_replacement`**
- Find all 2-element combinations of `"ABCD"`.
- Find all 2-element combinations **with replacement** of `"ABCD"`.

**Exercise 7 — `permutations`**
- List all 3-letter permutations of `"ABC"`.

**Exercise 8 — `product`**
- Compute the Cartesian product of `[1,2]` and `['X','Y']`.
- Repeat the product twice.

**Exercise 9 — `starmap`**
- Use `starmap` to apply `pow(x,y)` on `[(2,3),(3,2),(4,1)]`.

**Exercise 10 — `tee`**
- Duplicate an iterator over `[1,2,3]` into 3 independent iterators and print their elements.

**Exercise 11 — `zip_longest`**
- Zip `[1,2,3]` and `['a','b']` with `fillvalue='?'`.

### Section 3 — Filtering / Slicing Iterators

**Exercise 12 — `dropwhile`**
- Skip numbers in `[1,2,3,4,1,2]` while the number is less than 3.

**Exercise 13 — `takewhile`**
- Take numbers from `[1,2,3,4,1,2]` while they are less than 3.

**Exercise 14 — `filterfalse`**
- Filter out even numbers from `[1,2,3,4,5,6]`.

**Exercise 15 — `islice`**
- Slice `[0,1,2,3,4,5,6,7,8,9]` to get every 2nd element starting from index 1 to 7.

**Exercise 16 — `compress`**
- Select elements `[10,20,30,40]` where `[True, False, True, False]`.

### Section 4 — Combinatoric Helpers / Utilities

**Exercise 17 — `pairwise`**
- Print consecutive pairs of `[1,2,3,4]`.

**Exercise 18 — Combined Itertools**
- Chain two iterables, filter out even numbers, take the first 3 results, and compute the running sum.

**Exercise 19 — `repeat` + `islice`**
- Repeat `"Hello"` infinitely and print the first 5 occurrences using `islice`.

**Exercise 20 — Advanced Product & Permutations**
- Compute all 2-element tuples from `[1,2,3]` using both `product` and `permutations` and compare lengths.

---

## Solutions

### Solution 1 — `count`
```python
from itertools import count
c = count(10, 3)
for _ in range(5):
    print(next(c))
```

### Solution 2 — `cycle`
```python
from itertools import cycle
cy = cycle(["A", "B", "C"])
for _ in range(10):
    print(next(cy))
```

### Solution 3 — `repeat`
```python
from itertools import repeat, islice
for x in repeat("Hello", 5):
    print(x)
for x in islice(repeat(42), 7):
    print(x)
```

### Solution 4 — `accumulate`
```python
from itertools import accumulate
import operator
print(list(accumulate([1,2,3,4])))
print(list(accumulate([1,2,3,4], operator.mul)))
```

### Solution 5 — `chain`
```python
from itertools import chain
print(list(chain([1,2],[3,4])))
print(list(chain.from_iterable([[1,2],[3,4],[5]])))
```

### Solution 6 — `combinations` and `combinations_with_replacement`
```python
from itertools import combinations, combinations_with_replacement
print(list(combinations("ABCD",2)))
print(list(combinations_with_replacement("ABCD",2)))
```

### Solution 7 — `permutations`
```python
from itertools import permutations
print(list(permutations("ABC",3)))
```

### Solution 8 — `product`
```python
from itertools import product
print(list(product([1,2], ['X','Y'])))
print(list(product([1,2], ['X','Y'], repeat=2)))
```

### Solution 9 — `starmap`
```python
from itertools import starmap
print(list(starmap(pow, [(2,3),(3,2),(4,1)])))
```

### Solution 10 — `tee`
```python
from itertools import tee
it1, it2, it3 = tee(iter([1,2,3]), 3)
print(list(it1), list(it2), list(it3))
```

### Solution 11 — `zip_longest`
```python
from itertools import zip_longest
print(list(zip_longest([1,2,3], ['a','b'], fillvalue='?')))
```

### Solution 12 — `dropwhile`
```python
from itertools import dropwhile
print(list(dropwhile(lambda x: x<3, [1,2,3,4,1,2])))
```

### Solution 13 — `takewhile`
```python
from itertools import takewhile
print(list(takewhile(lambda x: x<3, [1,2,3,4,1,2])))
```

### Solution 14 — `filterfalse`
```python
from itertools import filterfalse
print(list(filterfalse(lambda x: x%2==1, [1,2,3,4,5,6])))
```

### Solution 15 — `islice`
```python
from itertools import islice
print(list(islice(range(10),1,8,2)))
```

### Solution 16 — `compress`
```python
from itertools import compress
print(list(compress([10,20,30,40],[True, False, True, False])))
```

### Solution 17 — `pairwise`
```python
from itertools import pairwise
print(list(pairwise([1,2,3,4])))
```

### Solution 18 — Combined Itertools
```python
from itertools import chain, filterfalse, accumulate, islice
lst = chain([1,2,3],[4,5])
filtered = filterfalse(lambda x: x%2==0, lst)
taken = islice(filtered, 3)
print(list(accumulate(taken)))
```

### Solution 19 — `repeat` + `islice`
```python
from itertools import repeat, islice
print(list(islice(repeat("Hello"),5)))
```

### Solution 20 — Advanced Product & Permutations
```python
from itertools import product, permutations
lst = [1,2,3]
print(list(product(lst, repeat=2)))
print(list(permutations(lst,2)))
```
'''

# Save to file
file_path = 'itertools_exercises_workbook.md'
with open(file_path, 'w', encoding='utf-8') as f:
    f.write(md_content)

print(f'Markdown workbook generated: {file_path}')