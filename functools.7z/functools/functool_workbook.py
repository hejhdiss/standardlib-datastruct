# Markdown content for Advanced Python functools Exercises Workbook
# generated and saved to a .md file
# Created by ChatGPT
# Modyfied by Muhammed Shafin P
# for pdf used commands:
# pandoc functools_exercises_workbook.md -o functools_exercises_workbook.pdf --pdf-engine=xelatex -V title="Advanced Python Functools Workbook" -V author="Muhammed Shafin P" -V date="02-01-2026"
# Pdf generated on 02-01-2026
# Pdf genearted with xelatex engine by MikTeX
# Pdf genrated using pandoc

md_content = '''
# Advanced Python `functools` Exercises Workbook

> **Instructions:** Solve the following exercises using Python. The solutions are provided in the **Solutions** section at the end.

## Exercises

### Exercise 1 — `lru_cache` Basics
Create a recursive function to compute Fibonacci numbers. Use `functools.lru_cache` to optimize it. Test the performance difference with and without caching.

### Exercise 2 — `cache` vs `lru_cache`
Write a function that computes factorial. Apply `functools.cache` to it. Compare its behavior with an `lru_cache` limited to 3 entries. Explain in comments when entries get evicted.

### Exercise 3 — `partial` Usage
Use `functools.partial` to create a new function `multiply_by_5` from a generic `multiply(x, y)` function.

### Exercise 4 — `partialmethod` in Classes
Define a class `Logger` with a method `log(level, message)`. Use `functools.partialmethod` to create `info()` and `error()` methods with preset log levels.

### Exercise 5 — `wraps` and Custom Decorators
Create a decorator `timeit` that measures execution time. Use `functools.wraps` to preserve the original function’s metadata.

### Exercise 6 — `update_wrapper` Manual Version
Rewrite Exercise 5 but **manually** use `functools.update_wrapper` instead of `wraps`.

### Exercise 7 — `total_ordering` Implementation
Create a class `Version` representing software versions (major, minor, patch). Use `@total_ordering` and implement `__eq__` and `__lt__`. Demonstrate sorting a list of `Version` instances.

### Exercise 8 — `singledispatch`
Implement a function `describe(obj)` using `functools.singledispatch` that:
- Prints "Unknown type" by default
- Prints "Integer" for ints
- Prints "String of length X" for strings

### Exercise 9 — `singledispatchmethod`
Create a class `Processor` with a method `process(data)` that is a `singledispatchmethod`. Handle lists and dictionaries differently.

### Exercise 10 — `reduce` to Compute
Use `functools.reduce` to compute:
- The product of all elements in a list
- The maximum element in a list

### Exercise 11 — `cmp_to_key` for Sorting
Sort a list of strings by **length first, then alphabetically** using `cmp_to_key`.

### Exercise 12 — Combining `partial` and `lru_cache`
Create a cached function that multiplies two numbers. Use `partial` to create a specialized function `double(x)` (multiply by 2). Demonstrate caching behavior.

### Exercise 13 — `wraps` + `singledispatch`
Create a `singledispatch` function with a decorator that logs the argument type before calling the function. Use `wraps` to preserve function metadata.

### Exercise 14 — Edge Cases with `lru_cache`
Write a function decorated with `lru_cache(maxsize=2)` and call it with **more unique arguments than maxsize**. Print cache info and explain what happens in comments.

### Exercise 15 — Advanced Combination
- Implement a `Calculator` class.
- Use `partialmethod` to create `add_10`, `multiply_by_5`.
- Use `lru_cache` to memoize expensive calculations.
- Use `total_ordering` to compare results.

## Solutions

### Solution 1 — `lru_cache` Basics
```python
from functools import lru_cache
import time

@lru_cache(maxsize=None)
def fib(n):
    if n < 2:
        return n
    return fib(n-1) + fib(n-2)

start = time.time()
print(fib(35))
print("Time with lru_cache:", time.time() - start)
```

### Solution 2 — `cache` vs `lru_cache`
```python
from functools import cache, lru_cache

@cache
def factorial(n):
    return 1 if n == 0 else n * factorial(n-1)

@lru_cache(maxsize=3)
def factorial_lru(n):
    return 1 if n == 0 else n * factorial_lru(n-1)

print(factorial(5))
print(factorial_lru(5))
```

### Solution 3 — `partial` Usage
```python
from functools import partial

def multiply(x, y):
    return x * y

multiply_by_5 = partial(multiply, 5)
print(multiply_by_5(10))  # 50
```

### Solution 4 — `partialmethod` in Classes
```python
from functools import partialmethod

class Logger:
    def log(self, level, message):
        print(f"[{level}] {message}")

    info = partialmethod(log, "INFO")
    error = partialmethod(log, "ERROR")

log = Logger()
log.info("Server started")
log.error("Server crashed")
```

### Solution 5 — `wraps` Decorator
```python
from functools import wraps
import time

def timeit(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        print(f"Execution time: {time.time() - start}")
        return result
    return wrapper

@timeit
def compute():
    sum(range(1000000))

compute()
```

### Solution 6 — `update_wrapper` Manual Version
```python
from functools import update_wrapper
import time

def timeit(func):
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        print(f"Execution time: {time.time() - start}")
        return result
    return update_wrapper(wrapper, func)

@timeit
def compute():
    sum(range(1000000))

compute()
```

### Solution 7 — `total_ordering`
```python
from functools import total_ordering

@total_ordering
class Version:
    def __init__(self, major, minor, patch):
        self.major = major
        self.minor = minor
        self.patch = patch

    def __eq__(self, other):
        return (self.major, self.minor, self.patch) == (other.major, other.minor, other.patch)

    def __lt__(self, other):
        return (self.major, self.minor, self.patch) < (other.major, other.minor, other.patch)

versions = [Version(1,2,3), Version(1,1,5), Version(2,0,0)]
print(sorted(versions, key=lambda v: (v.major, v.minor, v.patch)))
```

### Solution 8 — `singledispatch`
```python
from functools import singledispatch

@singledispatch
def describe(obj):
    print("Unknown type")

@describe.register(int)
def _(obj):
    print("Integer")

@describe.register(str)
def _(obj):
    print(f"String of length {len(obj)}")

describe(5)
describe("Hello")
describe([1,2])
```

### Solution 9 — `singledispatchmethod`
```python
from functools import singledispatchmethod

class Processor:
    @singledispatchmethod
    def process(self, data):
        print("Unsupported type")

    @process.register
    def _(self, data: list):
        print("Processing list")

    @process.register
    def _(self, data: dict):
        print("Processing dict")

p = Processor()
p.process([1,2,3])
p.process({'a':1})
```

### Solution 10 — `reduce`
```python
from functools import reduce
import operator

lst = [1,2,3,4]
product = reduce(operator.mul, lst)
maximum = reduce(max, lst)
print(product, maximum)
```

### Solution 11 — `cmp_to_key`
```python
from functools import cmp_to_key

def compare(a, b):
    return len(a) - len(b) if len(a) != len(b) else (1 if a > b else -1)

words = ["apple", "bat", "banana"]
sorted_words = sorted(words, key=cmp_to_key(compare))
print(sorted_words)
```

### Solution 12 — `partial` + `lru_cache`
```python
from functools import lru_cache, partial

@lru_cache(maxsize=None)
def multiply(x, y):
    return x * y

double = partial(multiply, 2)
print(double(5))
print(double(10))
```

### Solution 13 — `wraps` + `singledispatch`
```python
from functools import singledispatch, wraps

def log_type(func):
    @wraps(func)
    def wrapper(arg):
        print(f"Type of arg: {type(arg)}")
        return func(arg)
    return wrapper

@singledispatch
@log_type
def process(x):
    print("Default")

@process.register(int)
def _(x):
    print("Integer")

process(5)
process("Hello")
```

### Solution 14 — `lru_cache` Edge Cases
```python
from functools import lru_cache

@lru_cache(maxsize=2)
def square(x):
    return x*x

print(square(1))
print(square(2))
print(square(3))
print(square.cache_info())  # Observe evictions
```

### Solution 15 — Advanced Combination
```python
from functools import partialmethod, lru_cache, total_ordering

@total_ordering
class Calculator:
    def __init__(self, value):
        self.value = value

    @lru_cache(maxsize=None)
    def add(self, x):
        return self.value + x

    add_10 = partialmethod(add, 10)
    multiply_by_5 = partialmethod(add, 5)  # simplified for demo

    def __eq__(self, other):
        return self.value == other.value
    def __lt__(self, other):
        return self.value < other.value

c1 = Calculator(10)
c2 = Calculator(15)
print(c1.add_10())
print(c2.multiply_by_5())
print(c1 < c2)
```
'''

# Save to file
file_path = 'functools_exercises_workbook.md'
with open(file_path, 'w',encoding='utf-8') as f:
    f.write(md_content)

file_path
