# Advanced Python `collections` Module — Exercises Workbook

> **Goal:** Master high‑performance container datatypes from Python’s `collections` module.
> **Rule:** Order of questions does **not** matter — **coverage does**.

---

## Collections Covered

- Counter
- defaultdict
- deque
- namedtuple
- typing.NamedTuple
- ChainMap
- OrderedDict

---

## Exercises

### Exercise 1 — `Counter` Basics
Create a `Counter` from a string and display character frequencies.

### Exercise 2 — `Counter.elements()`
Use `elements()` to reconstruct the original iterable (ignoring order).

### Exercise 3 — `Counter.most_common()`
Find the 3 most common elements from a list of words.

### Exercise 4 — `Counter.subtract()`
Subtract counts using another iterable and observe zero/negative counts.

### Exercise 5 — `Counter` Arithmetic
Demonstrate `+`, `-`, `&`, and `|` between two Counters.

---

### Exercise 6 — `defaultdict` Initialization
Create a `defaultdict(list)` and append values without checking keys.

### Exercise 7 — `defaultdict` vs `dict`
Show how `dict` raises `KeyError` where `defaultdict` does not.

### Exercise 8 — `default_factory`
Inspect and modify the `default_factory` attribute.

---

### Exercise 9 — `deque` Basics
Create a deque and perform `append` and `appendleft`.

### Exercise 10 — `deque` Pops
Use `pop()` and `popleft()` and observe order.

### Exercise 11 — `deque.rotate()`
Rotate a deque both left and right.

### Exercise 12 — Fixed‑length `deque`
Create a deque with `maxlen` and show automatic discarding.

---

### Exercise 13 — `namedtuple` Creation
Create a `namedtuple` for a `Point(x, y)`.

### Exercise 14 — Field Access
Access namedtuple fields by name and index.

### Exercise 15 — `_asdict()` and `_replace()`
Convert a namedtuple to a dict and replace one field.

### Exercise 16 — `_make()`
Create a namedtuple instance from an iterable.

### Exercise 17 — `typing.NamedTuple`
Define a class‑style NamedTuple with type hints.

---

### Exercise 18 — `ChainMap` Lookup
Combine multiple dictionaries and demonstrate lookup order.

### Exercise 19 — `ChainMap` Assignment
Modify a key and show it only affects the first mapping.

### Exercise 20 — `new_child()` and `parents`
Use ChainMap to simulate variable scopes.

---

### Exercise 21 — `OrderedDict` Order Preservation
Insert keys and show iteration preserves order.

### Exercise 22 — `move_to_end()`
Move elements to front and end.

### Exercise 23 — `popitem()` Behavior
Remove items from both ends.

### Exercise 24 — Reverse Iteration
Iterate over an OrderedDict in reverse order.

---

## Solutions

### Solution 1 — `Counter` Basics
```python
from collections import Counter
c = Counter('banana')
print(c)
```

### Solution 2 — `Counter.elements()`
```python
print(list(c.elements()))
```

### Solution 3 — `Counter.most_common()`
```python
words = ['a','b','a','c','b','a']
print(Counter(words).most_common(3))
```

### Solution 4 — `Counter.subtract()`
```python
c1 = Counter(a=4, b=2)
c1.subtract({'a': 1, 'b': 3})
print(c1)
```

### Solution 5 — Arithmetic Operations
```python
c1 = Counter(a=3, b=1)
c2 = Counter(a=1, b=2)
print(c1 + c2)
print(c1 - c2)
print(c1 & c2)
print(c1 | c2)
```

---

### Solution 6 — `defaultdict` Initialization
```python
from collections import defaultdict
d = defaultdict(list)
d['a'].append(1)
d['a'].append(2)
print(d)
```

### Solution 7 — `defaultdict` vs `dict`
```python
d = defaultdict(int)
print(d['missing'])
```

### Solution 8 — `default_factory`
```python
print(d.default_factory)
d.default_factory = list
```

---

### Solution 9 — `deque` Basics
```python
from collections import deque
dq = deque([1,2,3])
dq.append(4)
dq.appendleft(0)
print(dq)
```

### Solution 10 — Pops
```python
print(dq.pop())
print(dq.popleft())
```

### Solution 11 — Rotation
```python
dq.rotate(2)
dq.rotate(-1)
print(dq)
```

### Solution 12 — Fixed Length
```python
dq = deque(maxlen=3)
dq.extend([1,2,3,4])
print(dq)
```

---

### Solution 13 — `namedtuple`
```python
from collections import namedtuple
Point = namedtuple('Point', ['x','y'])
p = Point(1, 2)
```

### Solution 14 — Field Access
```python
print(p.x, p[1])
```

### Solution 15 — `_asdict()` and `_replace()`
```python
print(p._asdict())
print(p._replace(x=10))
```

### Solution 16 — `_make()`
```python
p2 = Point._make([5, 6])
print(p2)
```

### Solution 17 — `typing.NamedTuple`
```python
from typing import NamedTuple
class User(NamedTuple):
    id: int
    name: str
```

---

### Solution 18 — `ChainMap` Lookup
```python
from collections import ChainMap
a = {'x': 1}
b = {'x': 2, 'y': 3}
cm = ChainMap(a, b)
print(cm['x'], cm['y'])
```

### Solution 19 — Assignment
```python
cm['x'] = 100
print(a, b)
```

### Solution 20 — Scopes
```python
child = cm.new_child({'z': 9})
print(child)
print(child.parents)
```

---

### Solution 21 — `OrderedDict`
```python
from collections import OrderedDict
od = OrderedDict()
od['a'] = 1
od['b'] = 2
print(list(od.keys()))
```

### Solution 22 — `move_to_end()`
```python
od.move_to_end('a')
od.move_to_end('b', last=False)
print(od)
```

### Solution 23 — `popitem()`
```python
od.popitem()
od.popitem(last=False)
```

### Solution 24 — Reverse Iteration
```python
for k in reversed(od):
    print(k)
```

